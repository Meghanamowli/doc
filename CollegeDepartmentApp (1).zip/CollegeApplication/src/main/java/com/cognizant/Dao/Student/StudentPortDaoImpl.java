package com.cognizant.Dao.Student;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.StudentDetSkell;
import com.cognizant.model.StudentPortSkell;
import com.cognizant.repository.StudentPortRepository;

@Service
public class StudentPortDaoImpl implements StudentPortDao 
{
	@Autowired
	StudentPortRepository studentPortRepository;
	
	@Override
	public void updateStudentPort(StudentPortSkell studentPortSkell) 
	{
		// TODO Auto-generated method stub
		studentPortRepository.save(studentPortSkell);
	}

	@Override
	public StudentPortSkell validateStudent(StudentPortSkell studentPortSkell) {
		// TODO Auto-generated method stub
		StudentPortSkell studentPortSkell1 = studentPortRepository.findByLoginData(studentPortSkell.getStudentUsn(),studentPortSkell.getStudentPassword());
		return studentPortSkell1;
	}

	@Override
	public void addStudentPort(StudentPortSkell studentPortSkell) 
	{
		// TODO Auto-generated method stub
		studentPortRepository.save(studentPortSkell);

	}
	
	@Override
	public void deleteStudentPort(String studentUsn) 
	{
		// TODO Auto-generated method stub
		studentPortRepository.deleteById(studentUsn);
	}

	@Override
	public List<StudentPortSkell> getAllStudent() 
	{
		List<StudentPortSkell> studentPortSkellLsit = studentPortRepository.findAll();
		return studentPortSkellLsit;
	}

	@Override
	public StudentPortSkell getStudentByUsn(String studentUsn) 
	{
		StudentPortSkell studentPortSkell = studentPortRepository.getById(studentUsn);
		return studentPortSkell;
	}
}
