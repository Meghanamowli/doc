package com.cognizant.Dao.Student;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.StudentDetSkell;
import com.cognizant.repository.StudentDetRepository;

@Service
public class StudentDetDaoImpl implements StudentDetDao 
{
	@Autowired
	StudentDetRepository studentDetRepository;
	
	@Override
	public void addStudent(StudentDetSkell studentDetSkell) 
	{
		// TODO Auto-generated method stub
		studentDetRepository.save(studentDetSkell);
	}

	@Override
	public StudentDetSkell getStudentByUsn(String studentUsn) 
	{
		// TODO Auto-generated method stub
		StudentDetSkell studentDetSkell = studentDetRepository.getById(studentUsn);
		return studentDetSkell;
	}

	@Override
	public void updateStudentDet(StudentDetSkell studentDetSkell) 
	{
		// TODO Auto-generated method stub
		studentDetRepository.save(studentDetSkell);
	}

	@Override
	public List<StudentDetSkell> getAllStudent() 
	{
		// TODO Auto-generated method stub
		List<StudentDetSkell> studentDetSkellLsit = studentDetRepository.findAll();
		return studentDetSkellLsit;
	}

	@Override
	public void deleteStudentDet(String studentUsn) 
	{
		// TODO Auto-generated method stub
		studentDetRepository.deleteById(studentUsn);
	}
}
