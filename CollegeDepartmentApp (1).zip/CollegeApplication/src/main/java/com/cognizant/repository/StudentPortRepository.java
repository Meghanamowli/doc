package com.cognizant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.StudentPortSkell;

@Repository
public interface StudentPortRepository extends JpaRepository<StudentPortSkell, String>
{
	@Query("select sp from StudentPortSkell sp where sp.studentUsn=(:studentUsn) and sp.studentPassword=(:studentPassword)")
	StudentPortSkell findByLoginData(String studentUsn, String studentPassword);
}
