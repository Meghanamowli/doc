package com.cognizant.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "StaffPortalDetails")
@Component
public class StaffPortSkell 
{
	@Id
	private String staffId;
	private String staffName;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date staffDoj;
	private Long staffPhNum;
	private String staffEmail;
	private String staffPassword;
	
	
	public StaffPortSkell() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StaffPortSkell(String staffId, String staffName, Date staffDoj, Long staffPhNum, String staffEmail,
			String staffPassword) {
		super();
		this.staffId = staffId;
		this.staffName = staffName;
		this.staffDoj = staffDoj;
		this.staffPhNum = staffPhNum;
		this.staffEmail = staffEmail;
		this.staffPassword = staffPassword;
	}
	public String getStaffId() {
		return staffId;
	}
	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	public String getStaffName() {
		return staffName;
	}
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	public Date getStaffDoj() {
		return staffDoj;
	}
	public void setStaffDoj(Date staffDoj) {
		this.staffDoj = staffDoj;
	}
	public Long getStaffPhNum() {
		return staffPhNum;
	}
	public void setStaffPhNum(Long staffPhNum) {
		this.staffPhNum = staffPhNum;
	}
	public String getStaffEmail() {
		return staffEmail;
	}
	public void setStaffEmail(String staffEmail) {
		this.staffEmail = staffEmail;
	}
	public String getStaffPassword() {
		return staffPassword;
	}
	public void setStaffPassword(String staffPassword) {
		this.staffPassword = staffPassword;
	}
	@Override
	public String toString() {
		return "StaffPortSkell [staffId=" + staffId + ", staffName=" + staffName + ", staffDoj=" + staffDoj
				+ ", staffPhNum=" + staffPhNum + ", staffEmail=" + staffEmail + ", staffPassword=" + staffPassword
				+ "]";
	}
}
